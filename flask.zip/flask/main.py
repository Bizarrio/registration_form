import os.path

from flask import Flask, render_template, redirect
from data import db_session
from data.users import User
from data.jobs import Jobs
from forms.user import RegisterForm
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def add_user(surname=None,
             name=None,
             position=None,
             speciality=None,
             address=None,
             email=None):
    new_user = User()
    new_user.surname = surname
    new_user.name = name
    new_user.position = position
    new_user.speciality = speciality
    new_user.address = address
    new_user.email = email

    db_sess = db_session.create_session()
    db_sess.add(new_user)
    db_sess.commit()


def add_job(team_leader=None,
            job=None,
            work_size=None,
            collaborators=None):
    new_job = Jobs()
    new_job.team_leader = team_leader
    new_job.job = job
    new_job.work_size = work_size
    new_job.collaborators = collaborators
    new_job.start_date = str(datetime.datetime.now().date())
    new_job.is_finished = False

    db_sess = db_session.create_session()
    db_sess.add(new_job)
    db_sess.commit()


def main():
    db_session.global_init("db/blogs.db")
    db_sess = db_session.create_session()

    add_user(surname="Scott",
             name="Ridley",
             position="captain",
             speciality="research engineer",
             address="module_1",
             email="scott_chief@mars.org")

    add_user(surname="Smith",
             name="John",
             position="engineer",
             speciality="mechanical",
             address="module_1",
             email="john_smith@mars.org")

    add_user(surname="Johnson",
             name="Mary",
             position="botanist",
             speciality="agriculture",
             address="module_1",
             email="mary_johnson@mars.org")

    add_user(surname="Lopez",
             name="Sofia",
             position="psychologist",
             speciality="human behavior",
             address="module_1",
             email="sofia_lopez@mars.org")

    add_user(surname="Wu",
             name="Li",
             position="chemist",
             speciality="environmental",
             address="module_5",
             email="li_wu@mars.org")

    add_job(team_leader=1,
            job="deployment of residential modules 1 and 2",
            work_size=15,
            collaborators="2, 3")

    add_job(team_leader=2,
            job="Exploration of mineral resources",
            work_size=15,
            collaborators="1, 2")

    add_job(team_leader=3,
            job="Development of a management system",
            work_size=25,
            collaborators="1, 2")

    # # Изменение атрибутов
    # user = db_sess.query(User).filter(User.id == 1).first()
    # user.name = "Измененное имя пользователя"
    # user.created_date = datetime.datetime.now()
    # db_sess.commit()
    #
    # # Создание новости через добавление к списку новостей User
    # user = db_sess.query(User).filter(User.id == 1).first()
    # news = Jobs(title="Личная запись", content="Эта запись личная",
    #             is_private=True)
    # user.news.append(news)
    # db_sess.commit()

    # for user in db_sess.query(User).filter((User.id > 1) | (User.email.notilike("%1%"))):
    #     print(user)

    # Удаление по фильтру
    # db_sess.query(User).filter(User.id >= 3).delete()
    # db_sess.commit()

    # Удаление отдельной записи
    # user = db_sess.query(User).filter(User.id == 2).first()
    # db_sess.delete(user)
    # db_sess.commit()

    # Создание новости по id
    # news = News(title="Первая новость", content="Привет блог!",
    #             user_id=1, is_private=False)
    # db_sess.add(news)
    # db_sess.commit()

    # Создание новости по объекту User
    # user = db_sess.query(User).filter(User.id == 1).first()
    # news = News(title="Вторая новость", content="Уже вторая запись!",
    #             user=user, is_private=False)
    # db_sess.add(news)
    # db_sess.commit()

    # Создание новости через добавление к списку новостей User
    # user = db_sess.query(User).filter(User.id == 1).first()
    # news = News(title="Личная запись", content="Эта запись личная",
    #             is_private=True)
    # user.news.append(news)
    # db_sess.commit()

    app.run()


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template("index.html", jobs=jobs)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            email=form.email,
            surname=form.surname,
            name=form.name,
            age=form.age,
            position=form.position,
            speciality=form.speciality,
            address=form.address)

        user.set_password(form.password.data)
        db_sess.add(user)
        print(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    if os.path.exists("db/blogs.db"):
        db_session.global_init("db/blogs.db")
        db_sess = db_session.create_session()
        app.run()
    else:
        main()
